#-------------------------------------------------#
# Title: Module 6 Homework
# Dev:   Cody Yarger
# Date:  02/17/2018
# Desc:  Manage To Do List with Functions
# ChangeLog: Cody Yarger, Rev New, 02/18/2018
#-------------------------------------------------#

############################################# Data ###########################################
# Open ToDo file for reading
File = "ToDo.txt"
ToDoFile = open(File, "r")

# Global Variables
lstTable = [] #Arguemnt passes to all functions
pri = "" # Argument passed to "add" item function, defined conditionally and as such needed here

############################################# Process ###########################################
class ToDoLists(object):
#This class contains a group of functions that display items contained in a list of x,y pairs, adds x,y pairs,
#removes x,y pairs and saves the list to a file.

    #---------------------------------------------------------------------------------------------------
    # This function extracts lines of data from a .txt file and stores them as a list of dictionaries
    #---------------------------------------------------------------------------------------------------
    # Store lines of data in ToDo.txt in a dictionary and store in a list
    @staticmethod
    def readFile(OpenFile):
        Indx = 0
        for lines in OpenFile:
            Indx = Indx + 1 # Set index equal to 0.
            Task, Priority = lines.strip().split(',')
            dictRow = {"Index":Indx,"Task":Task,"Priority":Priority}
            lstTable.append(dictRow)
        return lstTable
    #---------------------------------------------------------------------------------------------------
    # This function returns items in the list
    #---------------------------------------------------------------------------------------------------
    @staticmethod
    def PrintList(lst):
        # Show user list contents
        print("Here are the Tasks and Priorities in the ToDo List: " + '\n')
         # for rows in list print index, task and priority to console
        for rows in lst:
            print(str(rows["Index"]) + "  " + rows["Task"] + "(" + rows["Priority"] + ")")
    #---------------------------------------------------------------------------------------------------
    # This function adds new items to the list
    #---------------------------------------------------------------------------------------------------
    @staticmethod
    def AddItem(lst, item, priority):

        #Define local variables
        Indx = len(lst)
        Indx = Indx + 1

        # Define new task and priority in dictionary and append to list
        dictRow = {"Index":(Indx),"Task":item,"Priority":priority}
        lstTable.append(dictRow)

        return lstTable
    #---------------------------------------------------------------------------------------------------
    # This function removes items from the list
    #---------------------------------------------------------------------------------------------------
    @staticmethod
    def RemItem(lst, Rmv):
        # Delete sequence from list
        del lst[int(Rmv) - 1]
        # Create temp new list to rewrite indices
        Cnt = 0
        # for lines in list update indices
        lstTableNew = []
        for lines in lst:
            Cnt = Cnt + 1
            lines["Index"] = Cnt
            lstTableNew.append(lines)

        # Overwrite master list to update indices
        lstTable = list(lstTableNew)
        return lstTable
    #---------------------------------------------------------------------------------------------------
    # This writes the list to a file with the name defined in the "File" variable
    #---------------------------------------------------------------------------------------------------
    @staticmethod
    def SaveFile(lst, File):
            # Close file for reading and open for writing
            #ToDoFile.close()
            ToDoFile = open(File, 'w')
            # Write new list to file
            for DicRow in lst:
                ToDoFile.write(DicRow["Task"] + ',' + DicRow["Priority"] + '\n')

            print('''
            !! Your File was Saved !!
            ''')
            # Close ToDoFile
            ToDoFile.close()
    #---------------------------------------------------------------------------------------------------
############################################# Input/Output ########################################

# Read data in ToDoFile.txt
ToDoLists.readFile(ToDoFile)

# Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

    # Show the current items in the table
    if (strChoice.strip() == '1'):
        # Pass listTable as arg. to Print function
        ToDoLists.PrintList(lstTable)
        continue

    # Add a new item to the list/Table
    elif(strChoice.strip() == '2'):

        while(True):
            # Get new task to pass as argument to "add" function
            NewTask = input("Enter a new task. Type 'exit' for main menu: ")
            if(NewTask.lower() == 'exit'):
                break
            else:
                # Get new task priority to pass as argument to add function
                while(True):
                    Prior = input("Enter the task priority, High 'h' or Low 'l': ")

                    # if priority is high add High value to NewTask key
                    if Prior.lower() == 'h':
                        pri = "High"
                        break
                    # if priority is low add Low value to NewTask key
                    elif Prior.lower() == 'l':
                        pri = "Low"
                        break
                    # If user failed to enter "h" or "l" print error
                    else:
                        print("!! Error: That's not 'h' or 'l' !!")

                # Call add item function and pass lstTable, new task and priority as arguments
                ToDoLists.AddItem(lstTable, NewTask, pri)
        continue

    # Remove an item from the list/Table
    elif(strChoice == '3'):
        while(True):

            # Show user contents of task table
            print("Here are the Tasks and Priorities in the ToDo List: " + '\n')
            for rows in lstTable:
                print(str(rows["Index"]) + "  " + rows["Task"] + "(" + rows["Priority"] + ")")
            print()
            # Select task number and pass as argument to "remove" function
            strRmv = input("Select task number to remove, type 'exit' to stop: " + '\n')

            # If user exits return to main menu
            if(strRmv.lower() == 'exit'):
                break
            # Else delete list sequence
            else:
                while(True):
                    # Test to see if input is item number by converting to float
                    try: fltVal = float(strRmv)

                    # If float(fltVal) fails tell user to enter the item number
                    except ValueError: # If input not a number convert float fails and notifies user to enter number
                        print('!!! You need to enter the item number: !!!' + '\n' )
                        break

                    # If item is number and within range pass list and remove sequence as argument to "remove" function
                    if type(fltVal) == float and fltVal <= (len(lstTable)): #
                        ToDoLists.RemItem(lstTable, strRmv)
                        break

                    # Else if selection is not a number or out of range print message
                    else:
                        print('!!! You need to enter the item number: !!!' + '\n' )
                        break
        continue

    # Save tasks to the ToDoFile.txt file
    elif(strChoice == '4'):
        ToDoLists.SaveFile(lstTable, File)
        continue

    # Exit program if user types 'exit'
    elif (strChoice == '5'):
        break #and Exit the program
