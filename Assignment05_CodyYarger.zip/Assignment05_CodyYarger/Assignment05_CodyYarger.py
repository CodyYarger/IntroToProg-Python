#-------------------------------------------------#
# Title: Module 5 Homework
# Dev:   Cody Yarger
# Date:  02/06/2018
# Desc:  Manage To Do List
# ChangeLog: Cody Yarger, Rev New, 02/09/2018
#-------------------------------------------------#

# Declare variables and constants
# Open ToDo file for reading
ToDoFile = open("ToDo.txt", "r")

# Define downstream variables, lists and dictionaries
Prior = ""
spc = " "
lstTable = []
writeList = []
dictNItem = {}

# Store lines of data in ToDo.txt in a dictionary and store in a list
for lines in ToDoFile:
    Task, Priority = lines.strip().split(',')
    dictRow = {Task:Priority}
    lstTable.append(dictRow)

# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        # Show user list contents
        print("Here are the Tasks and Priorities in the ToDo List: " + '\n')
        item = 0
        for rows in lstTable:
            item = item + 1
            print(str(item) + spc + str(rows))
        continue

    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):

        # Get new task
        while(True):
            NewTask = input("Enter a new task. Type 'exit' for main menu: ")
            if(NewTask.lower() == 'exit'):
                break
            else:
                # Get new task priority
                while(True):
                    Prior = input("Enter the task priority, High 'h' or Low 'l': ")

                    # if priority is high add High value to NewTask key
                    if Prior is 'h':
                        dictNItem = {NewTask:" High"}
                        lstTable.append(dictNItem)
                        break
                    # if priority is low add Low value to NewTask key
                    elif Prior == 'l':
                        dictNItem = {NewTask:" Low"}
                        lstTable.append(dictNItem)
                        break
                    # If user failed to enter "h" or "l" print error
                    else:
                        print("!! Error: That's not 'h' or 'l' !!")

        continue

    # Step 5 - Remove an item from the list/Table
    elif(strChoice == '3'):

        # Prompt user to select task number to remove
        while(True):

            # Show user contents of task table
            print("Here are the Tasks and Priorities in the ToDo List: " + '\n')
            item = 0
            for rows in lstTable:
                item = item + 1
                print(str(item) + spc + str(rows))
                print()

            # Select task number
            strRmv = input("Select task number to remove, type 'exit' to stop: " + '\n')

            # If user exits return to main menu
            if(strRmv.lower() == 'exit'):
                break
            # Else delete list sequence
            else:
                while(True):
                    # Test to see if input is item number by converting to float
                    try: fltVal = float(strRmv)

                    # If float(fltVal) fails tell user to enter the item number
                    except ValueError: # If input not a number convert float fails and notifies user to enter number
                        print('!!! You need to enter the item number: !!!' + '\n' )
                        break

                    # Test if selection is in the list range
                    if type(fltVal) == float and fltVal <= (len(lstTable)): #
                        del lstTable[int(strRmv) - 1]
                        break

                    # Else if selection is not a number or out of range print message
                    else:
                        print('!!! You need to enter the item number: !!!' + '\n' )
                        break
            continue

    # Step 6 - Save tasks to the ToDoFile.txt file
    elif(strChoice == '4'):

        # Close file for reading and open for writing
        ToDoFile.close()
        ToDoFile = open('ToDo.txt', 'w')

        # Write new list to file
        for rows in lstTable:
            dictLine = rows
            for key,val in dictLine.items():
                ToDoFile.write(str(key) + ',' + str(val) + '\n')

    # Exit program if user types 'exit'
    elif (strChoice == '5'):
        break #and Exit the program


# Close ToDoFile
ToDoFile.close()

